# CS485-PHP-Database
Connect to your database using PHP
