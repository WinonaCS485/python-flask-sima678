<?php
$servername = "localhost:2234";
$username = "sx6525ir";
$password = "sx6525ir";
$dbname = "sx6525ir";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//$sql = "SELECT storeID, totalUnit FROM Sheet1";
$sql ="CREATE TABLE `sx6525ir`.`PWD` (
  `userID` varchar(11) DEFAULT NULL,
  `password` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8";
//$sql = "INSERT INTO PWD";
$sql = "INSERT INTO `PWD`(`userID`, `password`) VALUES ([Navin],[Clothes])";
$sql = "SELECT userID, password FROM PWD"
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "userID: " . $row["password"]. " -pwd: " . $row["password"]. "<br>";
    }
} else {
    echo "0 results";
}
$conn->close();
?> 
 