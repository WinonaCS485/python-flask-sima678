 <?php
$servername = "localhost:2234";
$username = "sx6525ir";
$password = "sx6525ir";
$dbname = "sx6525ir";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT storeID, totalUnit FROM Sheet1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "storeID: " . $row["storeID"]. " -totalUnit: " . $row["totalUnit"]. "<br>";
    }
} else {
    echo "0 results";
}
$conn->close();
?> 
 