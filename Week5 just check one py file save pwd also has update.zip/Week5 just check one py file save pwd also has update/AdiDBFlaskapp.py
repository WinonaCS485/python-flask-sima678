from flask import Flask, render_template
import pymysql.cursors



    
app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')
@app.route('/login')
def login():
    return render_template('post.html')

#@app.route("/hello/<name>')
#def hello(name):
##    return render_template('page.html, name)

  
@app.route('/db')
def display_db():
     # Connect to the database
    connection = pymysql.connect(host='mrbartucz.com',
                             user='sx6525ir',
                             password='sx6525ir',
                             db='sx6525ir_adi',
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)

    try:
        with connection.cursor() as cursor:
          # Select all Students
            sql = "SELECT * from BOD"
        
         # execute the SQL command
            cursor.execute(sql)
        
        # get the results
            #for result in cursor:
             #   print (result)
            data=cursor.fetchall()
      
        # If you INSERT, UPDATE or CREATE, the connection is not autocommit by default.
        # So you must commit to save your changes. 
        #connection.commit();
             # for row in data
                  #print("Id = ", row[0], 
                  #print("Sex = ", row[1])
              #   print("Age  = ", row[2], "\n")
        #print("  = ", row[3], "\n")
            return render_template('page.html', output_data=data)

    finally:
         connection.close()
    
if __name__ == '__main__':
     app.run(debug=True, port=3036)
    #app.run(debug=True, host='50.116.3.147')
   #app.run(debug=True, host='sx6525ir@localhost')