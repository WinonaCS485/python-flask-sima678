from flask import Flask, render_template, redirect, url_for, request
from flask import current_app as app
import sys , keyword



import pymysql.cursors
import datetime
    
app = Flask(__name__)
def formula():
    salt = "HoHoTuchBar"
    num1=9
    num2=44444
    salt = str(num1)+salt+str(num2)
    return salt

@app.route('/')
def index():
    return render_template('index.html')
#@app.route('/login')
def login():
    return render_template('post.html')
    #return render_template('enterPosthtmlagain.html')
@app.route('/post', methods = ['POST', 'GET'])
def post():
    if request.method =='POST':
        list =[request.form['User']]
        pwd = request.form['Password']
        
        print('I am inpost')
        user =list.pop(0)
        list.append(user)
        #res = [idx for idx, val in enumerate(list) if val == 0]
        ##return template.render(
    return render_template('enterPosthtmlagain.html')
@app.route('/repostmessage', methods = ['POST', 'GET'])
def repostmessage():
     if request.method =='POST':
        userA =request.form['User']
        pwdA = request.form['Password']
        '''Genrate salt with php formula'''
        h =hash(pwdA)
        print('I am in repost')
        ''' open datbase '''  
        connection = pymysql.connect(host='mrbartucz.com',
                             user='sx6525ir',
                             password='sx6525ir',
                             db='sx6525ir_University',
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)      
        salt=formula()
        passwordInfo = salt+str(h)
        sql = "INSERT INTO PWD (Username, Password) " "VALUES (%s, %s)"
        '''"INSERT INTO PWD (Username, Password) VALUES(?, ?)", (userA, passwordInfo)"I'''
        '''  else if(data == user):
             print("Please enter username again") 
             sql = "UPDATE INTO PWD (Username, Password) VALUES(?, ?)", (User, passwordInfo)'''
     else:
             print("Please enter username again") 
     cursor.execute(sql) 
     connection.commit()
        
       
     return redirect(url_for('database'))

 

@app.route('/database')        
def database():
    #if request.method =='GET':
        userd = request.args.get('User')
        pwd = request.args.get('Password')
        file = open( 'postN.txt' , 'w' )
        a = user + " "+pwd
        f = open("postN.txt", "a")
        f.write(a)
        print('I am indatabase') 
        #print(userA)
        print(passwordInfo)
        file.write( userd )
        #file.close()
        file = open( 'postN.txt', 'r' )
        if file.mode == 'r':
           contents =file.read()
        print(contents)
        file.close()
        ''' open datbase '''
        conn = pymysql.connect(host='mrbartucz.com',
                             user='sx6525ir',
                             password='sx6525ir',
                             db='sx6525ir_University',
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)
        sql ="INSERT INTO PWD (Username, Password) " "VALUES (%s, %s)"
        '''"INSERT INTO PWD (Username, Password) VALUES(?, ?)", (userA, passwordInfo)'''
        
       
        cursor.execute(sql)
        data=cursor.fetchall()
        yes ='yesitis'
        start = data.rfind("44444")
        i = data.rfind("!")
        datad=data.string[data.rfind("44444"):data.rfind("!")]
        
    #data =contents
        print(userd)
        if(data == " "):
            return render_template('post.html')
        elif data != userd:
            return render_template('enterPosthtmlagain.html')
        elif data == datad:
            return render_template('correctpwd.html')
        else:
            return render_template('page.html', output_data =datad)


        
    
if __name__ == '__main__':
    
     app.run(debug=True, port=8080)
