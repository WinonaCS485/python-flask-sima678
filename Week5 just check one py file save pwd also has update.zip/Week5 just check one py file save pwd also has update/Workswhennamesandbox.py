from flask import Flask, render_template, redirect, url_for, request
from flask import current_app as app
import sys , keyword


import pymysql.cursors
import datetime
    
app = Flask(__name__)
def formula():
    salt = "HoHoTuchBar"
    num1=9
    num2=44444
    salt = str(num1)+salt+str(num2)
    return salt

@app.route('/')
def index():
    return render_template('index.html')
#@app.route('/login')
#def login():
    #return render_template('post.html')
#    return render_template('enterPosthtmlagain.html')
@app.route('/post', methods = ['POST', 'GET'])
def post():
    if request.method =='POST':
        list =[request.form['User']]
        pwd = request.form['Password']
        user =list.pop(0)
        list.append(user)
        #res = [idx for idx, val in enumerate(list) if val == 0]
        ##return template.render(
    return render_template('enterPosthtmlagain.html')
@app.route('/repostmessage', methods = ['POST', 'GET'])
def repostmessage():
     if request.method =='POST':
        userA =request.form['User']
        pwdA = request.form['Password']
        '''Genrate salt with php formula'''
        h =hash(pwdA)
        print("I am in repost")
        #salt=formula()
        #passwordInfo = salt+str(h)
        '''file = open( 'post.txt' , 'w' )
        print(userA)
        print(passwordInfo)
        file.write( passwordInfo )
        file.close()'''
        
        ''' Mongo db'''
        '''mongoimport --host ClusterSMP-shard-0/clustersmp-shard-00-00-s6rtd.azure.mongodb.net:27017,'''
        '''clustersmp-shard-00-01-s6rtd.azure.mongodb.net:27017,clustersmp-shard-00-02-s6rtd.azure.mongodb.net:27017 '''
        '''--ssl --username SeemaSMP --password <PASSWORD> --authenticationDatabase '''
        '''admin --db <DATABASE> --collection <COLLECTION> --type <FILETYPE> --file <FILENAME>'''
        "mongodb0.example.com"
        ''' open datbase '''  
        connection = pymysql.connect(host='mongodb0.example.com',
                             user='Manu',
                             password='ThonyIsThere',
                             db='sx6525ir_Geo',
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)
        
        sql ="SELECT Username FROM PWD WHERE Username == User"
        ''' Nothing '''
        
        ''' open datbase '''  
        '''connection = pymysql.connect(host='mrbartucz.com',
                             user='sx6525ir',
                             password='sx6525ir',
                             db='sx6525ir_University',
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor) '''     
        salt=formula()
        passwordInfo = salt+str(h)
        sql ="SELECT Username FROM PWD WHERE Username == User"
        '''"INSERT INTO PWD (Username, Password) VALUES(?, ?)", (userA, passwordInfo)'''
        '''  else if(data == user):
             print("Please enter username again") 
             sql = "UPDATE INTO PWD (Username, Password) VALUES(?, ?)", (User, passwordInfo)
          else
             print("Please enter username again") '''
        cursor.execute(sql) 
        connection.commit()
        
       #db.session.add(task)
       #db.session.commit()
       
     return redirect(url_for('database'))

 

@app.route('/database')        
def database():
    #if request.method =='GET':
        userd = request.args.get('User')
        pwd = request.args.get('Password')
        file = open( 'postN.txt' , 'w' )
        a = user + " "+pwd
        f = open("postN.txt", "a")
        f.write(a)
        print('I am indatabase') 
        #print(userA)
        print(passwordInfo)
        file.write( userd )
        #file.close()
        file = open( 'postN.txt', 'r' )
        if file.mode == 'r':
           contents =file.read()
        print(contents)
        file.close()
        ''' open datbase '''
        connection = pymysql.connect(host='mrbartucz.com',
                             user='sx6525ir',
                             password='sx6525ir',
                             db='sx6525ir_adi',
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)
        sql = "SELECT ID SEX AGE FROM ADI WHERE ID == 6"
        cursor.execute(sql)
        data=cursor.fetchall()
        yes ='yesitis'
        start = data.rfind("44444")
        i = data.rfind("!")
        datad=data.string[data.rfind("44444"):data.rfind("!")]
        
    #data =contents
        print(userd)
        if(data == " "):
            return render_template('post.html')
        elif data != userd:
            return render_template('enterPosthtmlagain.html')
        elif data == datad:
            return render_template('correctpwd.html')
        else:
            return render_template('page.html', output_data =datad)


        
    
if __name__ == '__main__':
    
     app.run(debug=True, port=8080)
   





