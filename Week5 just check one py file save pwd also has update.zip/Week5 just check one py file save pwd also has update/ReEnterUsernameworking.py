from flask import Flask, render_template, redirect, url_for, request
from flask import current_app as app


import pymysql.cursors
import datetime
    
app = Flask(__name__)


@app.route('/')
def index():
    return render_template('index.html')
@app.route('/login')
def login():
    return render_template('post.html')
@app.route('/post', methods = ['POST', 'GET'])
def post():
    if request.method =='POST':
        list =[request.form['User']]
        pwd = request.form['Password']
        user =list.pop(0)
        list.append(user)
    return render_template('enterPosthtmlagain.html')
@app.route('/repostmessage', methods = ['POST', 'GET'])
def repostmessage():
     if request.method =='POST':
        userA =request.form['User']
        pwdA = request.form['Password']
        salt='HoHoTuchBar'
        h =hash(pwdA)
        passwordInfo = salt+str(h)
        print(userA)
        print(passwordInfo)
        #hennapic ="C:\webapp\post\Durga5.jpg"
     return redirect(url_for('database'))
#@app.route('/repostmessage)
#def repostmessage()
#      print('please enter your username again')

@app.route('/database')        
def database():
  
    file = open( 'post.txt', 'r' )
    if file.mode == 'r':
        contents =file.read()
    file.close()
    
   
    return render_template('page.html', output_data = contents)


        
    
if __name__ == '__main__':
    
    "mongodb://mongodb0.example.com:27017"
     app.run(debug=True, port=8080)